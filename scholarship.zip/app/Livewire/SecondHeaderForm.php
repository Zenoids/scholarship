<?php

namespace App\Livewire;

use Livewire\Component;

class SecondHeaderForm extends Component
{
    public function render()
    {
        return view('livewire.second-header-form');
    }
}
