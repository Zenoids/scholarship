<x-filament-panels::page>
    <livewire:add-course-form />
    <livewire:add-user-form />
    <livewire:add-state />
    <livewire:add-district />
</x-filament-panels::page>
