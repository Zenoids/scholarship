<div>
    <h2 class="text-6xl font-bold">Courses</h2>
    <div class="flex">

        <div class="w-1/2"><?php echo e($this->table); ?></div>  <form class="mx-auto" wire:submit="create">
            <?php echo e($this->form); ?>


            <button class="" type="submit">
                Submit
            </button>
        </form>
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\scholarship\resources\views/livewire/add-course-form.blade.php ENDPATH**/ ?>